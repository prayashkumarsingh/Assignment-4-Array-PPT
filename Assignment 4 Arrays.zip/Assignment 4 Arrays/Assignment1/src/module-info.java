/**
 * 
 */
/**
 * @author Prayash
 *
 */
module Assignment1 {
}